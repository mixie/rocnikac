var glob={
	 data:null,
	 svg:null
};

